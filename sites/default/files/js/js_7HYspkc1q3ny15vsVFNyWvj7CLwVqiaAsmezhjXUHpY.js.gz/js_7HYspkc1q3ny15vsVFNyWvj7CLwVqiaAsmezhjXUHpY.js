Drupal.behaviors.myBehavior = {
 attach: function (context, settings) {
   // Code here
 },
};
;
